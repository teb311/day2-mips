# Binary

Convert a binary number, represented as a string (e.g. '101010'), to its decimal equivalent using first principles. Implement binary to decimal conversion. Given a binary input string, your program should produce a decimal output.

Binary digit strings are given to you as null terminated ASCII strings in the test runner.

## Stretch it

Extend the test runner and your solution to include and handle invalid input
