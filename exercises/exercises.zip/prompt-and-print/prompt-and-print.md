# Prompt and Print

The purpose of this exercise is to help students understand the role of `syscall` in assembly language, as well as how to use it. The exercise is very straight forward: use syscall in MIPS to accept some user input as text, and print it to the screen.
